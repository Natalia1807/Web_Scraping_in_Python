# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse
from leroyparser.items import LeroyparserItem
from scrapy.loader import ItemLoader

class LmSpider(scrapy.Spider):
    name = 'lm'
    allowed_domains = ['leroymerlin.ru']
    # start_urls = ['http://leroymerlin.ru/']

    def __init__(self, find, region):
        self.start_urls = [f'https://{region}.leroymerlin.ru/search/?q={find}']

    def parse(self, response: HtmlResponse):
        next_page = response.xpath("//div[@class='next-paginator-button-wrapper']/a[@navy-arrow='next']/@href").extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse)
        ads_link = response.xpath("//div[@class='product-name']/a/@href").extract()
        for link in ads_link:
            yield response.follow(link, callback=self.parse_ads)

    def parse_ads(self, response: HtmlResponse):
        loader = ItemLoader(item=LeroyparserItem, response=response)
        loader.add_xpath('name', "//h1[@class='header-2']/text()")
        loader.add_xpath('price', "//span[@slot='price']/text()")
        loader.add_xpath('currency', "//span[@slot='currency']/text()")
        loader.add_xpath('unit', "//span[@slot='unit']/text()")
        loader.add_xpath('photos', "//picture[@slot='pictures']/source[@media=' only screen and (min-width: 1024px)']//@srcset")
        loader.add_xpath('param_name', "//dl[@class='def-list']//dt[@class='def-list__term']/text()")
        loader.add_xpath('param_values', "//dl[@class='def-list']//dd[@class='def-list__definition']/text()")
        yield loader.load_item()
        # name = response.xpath("//h1[@class='header-2']/text()").extract_first()
        # price = response.xpath("//span[@slot='price']/text()").extract_first()
        # currency = response.xpath("//span[@slot='currency']/text()").extract_first()
        # unit = response.xpath("//span[@slot='unit']/text()").extract_first()
        # photos = response.xpath("//picture[@slot='pictures']/source[@media=' only screen and (min-width: 1024px)']//@srcset").extract()
        # param_name = response.xpath("//dl[@class='def-list']//dt[@class='def-list__term']/text()")
        # param_values = response.xpath("//dl[@class='def-list']//dd[@class='def-list__definition']/text()")
        # link = response.url
        # yield LeroyparserItem(name=name, price=price, currency=currency, unit=unit, photos=photos, param_name=param_name, param_values=param_values, link=link)
        pass


