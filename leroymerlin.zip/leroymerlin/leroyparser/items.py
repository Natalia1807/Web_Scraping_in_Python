# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import TakeFirst, MapCompose
import re

def cleaner_param_values(value):
    value = re.findall('[^\s]*', value)
    return value


class LeroyparserItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    link = scrapy.Field()
    name = scrapy.Field(output_ptocessor=TakeFirst())
    price = scrapy.Field(output_ptocessor=TakeFirst())
    currency = scrapy.Field(output_ptocessor=TakeFirst())
    unit = scrapy.Field(output_ptocessor=TakeFirst())
    param_name = scrapy.Field()
    param_values = scrapy.Field(input_processor=MapCompose(cleaner_param_values()))
    photos = scrapy.Field()

    pass

