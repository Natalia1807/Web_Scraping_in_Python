from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings
from leroyparser import settings
from leroyparser.spiders.lm import LmSpider


if __name__ == '__main__':
    crawler_setting  = Settings()
    crawler_setting.setmodule(settings)

    process = CrawlerProcess(settings=crawler_setting)
    process.crawl(LmSpider, find = 'зеркало', region = 'kaluga') # передаем параметр, который будет вводить пользователь

    process.start()