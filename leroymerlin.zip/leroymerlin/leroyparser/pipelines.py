# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.pipelines.images import ImagesPipeline
import scrapy
from pymongo import MongoClient

class LeroyparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27007)
        self.mongo_base = client.leroy_photo


    def process_item(self, item, spider):
        collection = self.mongo_base[spider.name]
        collection.insert_one(item)
        return item

class LeroyPhotosPipline(ImagesPipeline):
    def get_media_requests(self, item, info):
        if item['photos']:
            for img in item['photos']:
                try:
                    yield scrapy.Request(f'{img}')
                except Exception as e:
                    print(e)

    def item_completed(self, results, item, info):
        if results:
            item['photos'] = [itm[1] for itm in results if itm[0]]
        return item



class  LeroyParamsPipeline(object):
    def process_item(self, item, spider):
        item['params'] = dict(zip(item['param_name'], item['param_values']))
        del item['param_name']
        del item['param_values']
        return item

