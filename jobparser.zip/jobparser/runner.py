from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings
from jobparser import settings
from jobparser.spiders.hhry import HhrySpider
from jobparser.spiders.sjry import SjrySpider

if __name__ == '__main__':
    crawler_setting  = Settings()
    crawler_setting.setmodule(settings)

    process = CrawlerProcess(settings=crawler_setting)
    process.crawl(HhrySpider)
    process.crawl(SjrySpider)

    process.start()



