# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from pymongo import MongoClient
import re

class JobparserPipeline(object):
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.jobparser

    def process_item(self, item, spider):
        collection = self.mongo_base[spider.name]
        collection.insert_one(item)
        if spider.name == 'hhry':
            if item['salary'][0] == 'от ':
                item['min_salary'] = item['salary'][1].replace('\xa0', '')
                item['max_salary'] = None
                item['currency'] = item['salary'][3]
            elif item['salary'][0] == 'до ':
                item['min_salary'] = None
                item['max_salary'] = item['salary'][1].replace('\xa0', '')
                item['currency'] = item['salary'][3]
            elif item['salary'][0] == '-':
                item['min_salary'] = item['salary'][1].replace('\xa0', '')
                item['max_salary'] = item['salary'][3].replace('\xa0', '')
                item['currency'] = item['salary'][5]
            else:
                item['min_salary'] = None
                item['max_salary'] = None
                item['currency'] = None
            item['site'] = 'https://hh.ru'



        if spider.name == 'sjru':
            if item['salary'][0] == 'По договорённости':
                item['min_salary'] = None
                item['max_salary'] = None
                item['currency'] = None
            elif item['salary'][0] == 'от':
                item['min_salary'] = (''.join(re.findall('\d', item['salary'][2])))
                item['max_salary'] = None
                item['currency'] = (''.join(re.findall('[а-яА-ЯёЁ]{3}', item['salary'][2])))
            elif item['salary'][0] == 'до':
                item['min_salary'] = None
                item['max_salary'] = (''.join(re.findall('\d', item['salary'][2])))
                item['currency'] = (''.join(re.findall('[а-яА-ЯёЁ]{3}', item['salary'][2])))
            elif len(item['salary']) >= 4:
                item['min_salary'] = (''.join(re.findall('\d', item['salary'][0])))
                item['max_salary'] = (''.join(re.findall('\d', item['salary'][1])))
                item['currency'] = item['salary'][4]
            else:
                item['min_salary'] = None
                item['max_salary'] = None
                item['currency'] = None
        item['site'] = 'https://www.superjob.ru'
        del item['salary']

        collection = self.mongo_base[spider.name]
        collection.insert_one(item)

        return item






